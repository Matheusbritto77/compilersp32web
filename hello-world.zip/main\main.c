#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

static const char *TAG = "HELLO_WORLD";

void app_main(void)
{
    ESP_LOGI(TAG, "Iniciando sistema de teste...");
    
    int count = 0;
    while (1) {
        printf("[%d] Hello World do seu novo compilador Web! 🚀\n", count++);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
